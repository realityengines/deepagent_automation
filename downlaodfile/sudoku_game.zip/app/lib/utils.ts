import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export const generateSudoku = () => {
  const grid = Array(9).fill(null).map(() => Array(9).fill(0));
  
  // Function to check if a number is valid in a given position
  const isValid = (num: number, pos: [number, number]) => {
    const [row, col] = pos;

    // Check row
    for (let x = 0; x < 9; x++) {
      if (grid[row][x] === num) return false;
    }

    // Check column
    for (let x = 0; x < 9; x++) {
      if (grid[x][col] === num) return false;
    }

    // Check box
    const boxRow = Math.floor(row / 3) * 3;
    const boxCol = Math.floor(col / 3) * 3;
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) {
        if (grid[boxRow + i][boxCol + j] === num) return false;
      }
    }

    return true;
  };

  // Function to fill the diagonal boxes
  const fillDiagonal = () => {
    for (let i = 0; i < 9; i += 3) {
      fillBox(i, i);
    }
  };

  // Function to fill a 3x3 box
  const fillBox = (row: number, col: number) => {
    let num;
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) {
        do {
          num = Math.floor(Math.random() * 9) + 1;
        } while (!isValid(num, [row + i, col + j]));
        grid[row + i][col + j] = num;
      }
    }
  };

  // Function to fill the remaining cells
  const fillRemaining = (row: number, col: number): boolean => {
    if (col >= 9 && row < 8) {
      row += 1;
      col = 0;
    }
    if (row >= 9 && col >= 9) return true;
    if (row < 3) {
      if (col < 3) col = 3;
    } else if (row < 6) {
      if (col === Math.floor(row / 3) * 3) col += 3;
    } else {
      if (col === 6) {
        row += 1;
        col = 0;
        if (row >= 9) return true;
      }
    }

    for (let num = 1; num <= 9; num++) {
      if (isValid(num, [row, col])) {
        grid[row][col] = num;
        if (fillRemaining(row, col + 1)) return true;
        grid[row][col] = 0;
      }
    }
    return false;
  };

  // Function to remove digits to create puzzle
  const removeDigits = (count: number) => {
    let removed = 0;
    while (removed < count) {
      const row = Math.floor(Math.random() * 9);
      const col = Math.floor(Math.random() * 9);
      if (grid[row][col] !== 0) {
        grid[row][col] = 0;
        removed++;
      }
    }
  };

  fillDiagonal();
  fillRemaining(0, 3);
  removeDigits(40); // Adjust difficulty by changing number of removed digits

  return grid;
};

export const checkSolution = (current: number[][], solution: number[][]) => {
  for (let i = 0; i < 9; i++) {
    for (let j = 0; j < 9; j++) {
      if (current[i][j] !== solution[i][j]) {
        return false;
      }
    }
  }
  return true;
};

export const isValidMove = (grid: number[][], row: number, col: number, num: number): boolean => {
  // Check row
  for (let x = 0; x < 9; x++) {
    if (x !== col && grid[row][x] === num) return false;
  }

  // Check column
  for (let x = 0; x < 9; x++) {
    if (x !== row && grid[x][col] === num) return false;
  }

  // Check 3x3 box
  const startRow = Math.floor(row / 3) * 3;
  const startCol = Math.floor(col / 3) * 3;
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      if (
        startRow + i !== row &&
        startCol + j !== col &&
        grid[startRow + i][startCol + j] === num
      ) {
        return false;
      }
    }
  }

  return true;
};