"use client"

import { motion } from "framer-motion"
import { useState, useEffect } from "react"
import { generateSudoku, isValidMove } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Gamepad2, RefreshCw, CheckCircle } from "lucide-react"

export default function Home() {
  const [grid, setGrid] = useState<number[][]>([])
  const [initialGrid, setInitialGrid] = useState<number[][]>([])
  const [selectedCell, setSelectedCell] = useState<[number, number] | null>(null)
  const [isComplete, setIsComplete] = useState(false)

  useEffect(() => {
    startNewGame()
  }, [])

  const startNewGame = () => {
    const newGrid = generateSudoku()
    setGrid(JSON.parse(JSON.stringify(newGrid)))
    setInitialGrid(JSON.parse(JSON.stringify(newGrid)))
    setIsComplete(false)
    setSelectedCell(null)
  }

  const handleCellClick = (row: number, col: number) => {
    if (initialGrid[row][col] === 0) {
      setSelectedCell([row, col])
    }
  }

  const handleNumberInput = (number: number) => {
    if (!selectedCell) return

    const [row, col] = selectedCell
    if (initialGrid[row][col] !== 0) return

    const newGrid = [...grid]
    if (isValidMove(newGrid, row, col, number)) {
      newGrid[row][col] = number
      setGrid(newGrid)

      // Check if the puzzle is complete
      const isGridComplete = newGrid.every((row) =>
        row.every((cell) => cell !== 0)
      )
      if (isGridComplete) {
        setIsComplete(true)
      }
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-2xl mx-auto"
      >
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-2">
            <Gamepad2 className="w-6 h-6" />
            <h1 className="text-2xl font-bold">Sudoku Game</h1>
          </div>
          <div className="flex space-x-4">
            <Button
              onClick={startNewGame}
              variant="outline"
              className="flex items-center space-x-2"
            >
              <RefreshCw className="w-4 h-4" />
              <span>New Game</span>
            </Button>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
          <div className="grid grid-cols-9 gap-1 mb-6">
            {grid.map((row, rowIndex) =>
              row.map((cell, colIndex) => (
                <motion.button
                  key={`${rowIndex}-${colIndex}`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`
                    aspect-square flex items-center justify-center text-lg font-bold
                    border ${
                      selectedCell?.[0] === rowIndex &&
                      selectedCell?.[1] === colIndex
                        ? "border-blue-500 bg-blue-100 dark:bg-blue-900"
                        : "border-gray-200 dark:border-gray-700"
                    }
                    ${
                      initialGrid[rowIndex][colIndex] !== 0
                        ? "bg-gray-100 dark:bg-gray-700"
                        : "hover:bg-gray-50 dark:hover:bg-gray-600"
                    }
                    ${
                      colIndex % 3 === 2 && colIndex !== 8
                        ? "border-r-2 border-r-black dark:border-r-white"
                        : ""
                    }
                    ${
                      rowIndex % 3 === 2 && rowIndex !== 8
                        ? "border-b-2 border-b-black dark:border-b-white"
                        : ""
                    }
                  `}
                  onClick={() => handleCellClick(rowIndex, colIndex)}
                  disabled={initialGrid[rowIndex][colIndex] !== 0}
                >
                  {cell !== 0 ? cell : ""}
                </motion.button>
              ))
            )}
          </div>

          <div className="grid grid-cols-9 gap-2">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((number) => (
              <motion.button
                key={number}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="aspect-square flex items-center justify-center text-lg font-bold bg-blue-500 text-white rounded-md hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700"
                onClick={() => handleNumberInput(number)}
              >
                {number}
              </motion.button>
            ))}
          </div>

          {isComplete && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 p-4 bg-green-100 dark:bg-green-900 rounded-lg flex items-center justify-center space-x-2"
            >
              <CheckCircle className="w-6 h-6 text-green-600 dark:text-green-400" />
              <span className="font-medium text-green-600 dark:text-green-400">
                Congratulations! You've completed the puzzle!
              </span>
            </motion.div>
          )}
        </div>
      </motion.div>
    </div>
  )
}