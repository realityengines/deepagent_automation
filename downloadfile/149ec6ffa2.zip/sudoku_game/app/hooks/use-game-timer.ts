import { useEffect } from 'react';
import { useGameStore } from '@/lib/game-state';

export function useGameTimer() {
  const { isPlaying, time, setTime } = useGameStore();

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isPlaying) {
      interval = setInterval(() => {
        setTime(time + 1);
      }, 1000);
    }

    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [isPlaying, time, setTime]);

  return time;
}