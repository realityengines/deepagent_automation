'use client';

import { Button } from './ui/button';
import { Eraser, Lightbulb, RotateCcw } from 'lucide-react';

export default function GameControls() {
  return (
    <div className="bg-card p-4 rounded-lg shadow-lg space-y-2">
      <Button variant="outline" className="w-full">
        <Lightbulb className="mr-2 h-4 w-4" />
        Hint
      </Button>
      <Button variant="outline" className="w-full">
        <Eraser className="mr-2 h-4 w-4" />
        Erase
      </Button>
      <Button variant="outline" className="w-full">
        <RotateCcw className="mr-2 h-4 w-4" />
        Reset
      </Button>
    </div>
  );
}