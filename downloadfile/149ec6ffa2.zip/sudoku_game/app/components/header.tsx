'use client';

import { motion } from 'framer-motion';
import { ModeToggle } from './mode-toggle';
import { Button } from './ui/button';
import { Home, Trophy, Settings } from 'lucide-react';
import Link from 'next/link';

export default function Header() {
  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-sm"
    >
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-6">
          <Link href="/">
            <Button variant="ghost" className="gap-2">
              <Home className="h-5 w-5" />
              Home
            </Button>
          </Link>
          <Link href="/leaderboard">
            <Button variant="ghost" className="gap-2">
              <Trophy className="h-5 w-5" />
              Leaderboard
            </Button>
          </Link>
          <Link href="/settings">
            <Button variant="ghost" className="gap-2">
              <Settings className="h-5 w-5" />
              Settings
            </Button>
          </Link>
        </div>
        <ModeToggle />
      </div>
    </motion.header>
  );
}