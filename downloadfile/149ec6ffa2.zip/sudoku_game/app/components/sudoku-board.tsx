'use client';

import { motion } from 'framer-motion';
import { useState, useEffect } from 'react';
import { generateSudoku, isValidMove, solveSudoku, getHint } from '@/lib/sudoku';
import { useGameStore } from '@/lib/game-state';
import { useGameTimer } from '@/hooks/use-game-timer';
import { Button } from './ui/button';
import { Lightbulb, RotateCcw, Eraser } from 'lucide-react';
import { toast } from 'sonner';

interface SudokuBoardProps {
  difficulty: 'easy' | 'medium' | 'hard';
}

export default function SudokuBoard({ difficulty }: SudokuBoardProps) {
  const {
    board,
    setBoard,
    initialBoard,
    setInitialBoard,
    selectedCell,
    setSelectedCell,
    hintsRemaining,
    setHintsRemaining,
    setIsPlaying,
    score,
    setScore
  } = useGameStore();

  const time = useGameTimer();

  useEffect(() => {
    const newBoard = generateSudoku(difficulty);
    setBoard(newBoard);
    setInitialBoard(newBoard.map(row => [...row]));
    setIsPlaying(true);
    setHintsRemaining(3);
  }, [difficulty, setBoard, setInitialBoard, setIsPlaying, setHintsRemaining]);

  const handleCellClick = (row: number, col: number) => {
    if (initialBoard[row][col] === 0) {
      setSelectedCell([row, col]);
    }
  };

  const handleNumberInput = (number: number) => {
    if (!selectedCell) return;
    const [row, col] = selectedCell;
    
    if (initialBoard[row][col] !== 0) return;

    const newBoard = board.map(row => [...row]);
    if (isValidMove(newBoard, row, col, number)) {
      newBoard[row][col] = number;
      setBoard(newBoard);
      setScore(score + 10);
      
      // Check if puzzle is solved
      if (!newBoard.some(row => row.includes(0))) {
        setIsPlaying(false);
        toast.success('Congratulations! You solved the puzzle!');
      }
    } else {
      toast.error('Invalid move!');
      setScore(Math.max(0, score - 5));
    }
  };

  const handleHint = () => {
    if (hintsRemaining <= 0) {
      toast.error('No hints remaining!');
      return;
    }

    const hint = getHint(board, initialBoard);
    if (!hint) {
      toast.error('No hint available!');
      return;
    }

    const [row, col, value] = hint;
    const newBoard = board.map(r => [...r]);
    newBoard[row][col] = value;
    setBoard(newBoard);
    setHintsRemaining(hintsRemaining - 1);
    setScore(Math.max(0, score - 20));
    toast.success('Hint used!');
  };

  const handleReset = () => {
    setBoard(initialBoard.map(row => [...row]));
    setScore(0);
    setIsPlaying(true);
    toast.info('Game reset!');
  };

  const handleErase = () => {
    if (!selectedCell) {
      toast.error('Select a cell first!');
      return;
    }
    
    const [row, col] = selectedCell;
    if (initialBoard[row][col] === 0) {
      const newBoard = board.map(row => [...row]);
      newBoard[row][col] = 0;
      setBoard(newBoard);
      toast.info('Cell erased!');
    } else {
      toast.error('Cannot erase initial numbers!');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="bg-card p-6 rounded-lg shadow-lg"
    >
      <div className="grid grid-cols-9 gap-0.5 mb-4">
        {board.map((row, rowIndex) =>
          row.map((cell, colIndex) => (
            <motion.div
              key={`${rowIndex}-${colIndex}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: (rowIndex * 9 + colIndex) * 0.01 }}
              className={`sudoku-cell
                ${selectedCell?.[0] === rowIndex && selectedCell?.[1] === colIndex
                  ? 'sudoku-cell-selected'
                  : ''}
                ${initialBoard[rowIndex][colIndex] !== 0 ? 'sudoku-cell-fixed' : ''}
                ${(rowIndex + 1) % 3 === 0 ? 'border-b-2' : ''}
                ${(colIndex + 1) % 3 === 0 ? 'border-r-2' : ''}
              `}
              onClick={() => handleCellClick(rowIndex, colIndex)}
            >
              {cell !== 0 ? cell : ''}
            </motion.div>
          ))
        )}
      </div>

      <div className="grid grid-cols-3 gap-2 mt-4">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((number) => (
          <motion.button
            key={number}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="p-3 bg-primary text-primary-foreground rounded-md"
            onClick={() => handleNumberInput(number)}
          >
            {number}
          </motion.button>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-2 mt-4">
        <Button onClick={handleHint} variant="outline" className="flex items-center gap-2">
          <Lightbulb className="h-4 w-4" />
          Hint ({hintsRemaining})
        </Button>
        <Button onClick={handleErase} variant="outline" className="flex items-center gap-2">
          <Eraser className="h-4 w-4" />
          Erase
        </Button>
        <Button onClick={handleReset} variant="outline" className="flex items-center gap-2">
          <RotateCcw className="h-4 w-4" />
          Reset
        </Button>
      </div>
    </motion.div>
  );
}