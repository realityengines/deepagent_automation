function generateEmptyBoard(): number[][] {
  return Array(9).fill(0).map(() => Array(9).fill(0));
}

function isValid(board: number[][], row: number, col: number, num: number): boolean {
  // Check row
  for (let x = 0; x < 9; x++) {
    if (board[row][x] === num) return false;
  }

  // Check column
  for (let x = 0; x < 9; x++) {
    if (board[x][col] === num) return false;
  }

  // Check 3x3 box
  const startRow = row - (row % 3);
  const startCol = col - (col % 3);
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      if (board[i + startRow][j + startCol] === num) return false;
    }
  }

  return true;
}

export function solveSudoku(board: number[][]): boolean {
  let row = -1;
  let col = -1;
  let isEmpty = false;

  // Find an empty cell
  for (let i = 0; i < 9; i++) {
    for (let j = 0; j < 9; j++) {
      if (board[i][j] === 0) {
        row = i;
        col = j;
        isEmpty = true;
        break;
      }
    }
    if (isEmpty) break;
  }

  // No empty cell found, puzzle is solved
  if (!isEmpty) return true;

  // Try digits 1-9
  for (let num = 1; num <= 9; num++) {
    if (isValid(board, row, col, num)) {
      board[row][col] = num;
      if (solveSudoku(board)) return true;
      board[row][col] = 0;
    }
  }

  return false;
}

function generateSolvedBoard(): number[][] {
  const board = generateEmptyBoard();
  
  // Fill diagonal 3x3 boxes
  for (let box = 0; box < 9; box += 3) {
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) {
        let num;
        do {
          num = Math.floor(Math.random() * 9) + 1;
        } while (!isValid(board, box + i, box + j, num));
        board[box + i][box + j] = num;
      }
    }
  }

  // Solve the rest of the board
  solveSudoku(board);
  return board;
}

export function generateSudoku(difficulty: 'easy' | 'medium' | 'hard'): number[][] {
  const solvedBoard = generateSolvedBoard();
  const board = solvedBoard.map(row => [...row]);
  
  const cellsToRemove = {
    easy: 30,
    medium: 45,
    hard: 55
  }[difficulty];

  let removed = 0;
  while (removed < cellsToRemove) {
    const row = Math.floor(Math.random() * 9);
    const col = Math.floor(Math.random() * 9);
    if (board[row][col] !== 0) {
      board[row][col] = 0;
      removed++;
    }
  }

  return board;
}

export function isValidMove(board: number[][], row: number, col: number, num: number): boolean {
  return isValid(board, row, col, num);
}

export function isBoardComplete(board: number[][]): boolean {
  return !board.some(row => row.includes(0));
}

export function getHint(board: number[][], initialBoard: number[][]): [number, number, number] | null {
  const solvedBoard = board.map(row => [...row]);
  
  if (solveSudoku(solvedBoard)) {
    for (let i = 0; i < 9; i++) {
      for (let j = 0; j < 9; j++) {
        if (board[i][j] === 0 && initialBoard[i][j] === 0) {
          return [i, j, solvedBoard[i][j]];
        }
      }
    }
  }
  
  return null;
}