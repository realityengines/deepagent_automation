import { create } from 'zustand';

interface GameState {
  board: number[][];
  initialBoard: number[][];
  selectedCell: [number, number] | null;
  difficulty: 'easy' | 'medium' | 'hard';
  score: number;
  time: number;
  isPlaying: boolean;
  hintsRemaining: number;
  setBoard: (board: number[][]) => void;
  setInitialBoard: (board: number[][]) => void;
  setSelectedCell: (cell: [number, number] | null) => void;
  setDifficulty: (difficulty: 'easy' | 'medium' | 'hard') => void;
  setScore: (score: number) => void;
  setTime: (time: number) => void;
  setIsPlaying: (isPlaying: boolean) => void;
  setHintsRemaining: (hints: number) => void;
}

export const useGameStore = create<GameState>((set) => ({
  board: Array(9).fill(Array(9).fill(0)),
  initialBoard: Array(9).fill(Array(9).fill(0)),
  selectedCell: null,
  difficulty: 'easy',
  score: 0,
  time: 0,
  isPlaying: false,
  hintsRemaining: 3,
  setBoard: (board) => set({ board }),
  setInitialBoard: (board) => set({ initialBoard: board }),
  setSelectedCell: (cell) => set({ selectedCell: cell }),
  setDifficulty: (difficulty) => set({ difficulty }),
  setScore: (score) => set({ score }),
  setTime: (time) => set({ time }),
  setIsPlaying: (isPlaying) => set({ isPlaying }),
  setHintsRemaining: (hints) => set({ hintsRemaining: hints }),
}));