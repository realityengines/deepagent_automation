'use client';

import { motion } from 'framer-motion';
import { Trophy, Clock, Star } from 'lucide-react';

interface LeaderboardEntry {
  id: number;
  name: string;
  score: number;
  time: number;
  difficulty: string;
  date: string;
}

const leaderboardData: LeaderboardEntry[] = [
  { id: 1, name: "Alex", score: 1000, time: 300, difficulty: "Hard", date: "2024-03-10" },
  { id: 2, name: "Sarah", score: 950, time: 320, difficulty: "Hard", date: "2024-03-09" },
  { id: 3, name: "Mike", score: 900, time: 400, difficulty: "Medium", date: "2024-03-08" },
  { id: 4, name: "Emma", score: 850, time: 450, difficulty: "Medium", date: "2024-03-07" },
  { id: 5, name: "John", score: 800, time: 500, difficulty: "Easy", date: "2024-03-06" },
];

export default function LeaderboardPage() {
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-8"
      >
        <h1 className="text-4xl font-bold mb-4 flex items-center justify-center gap-2">
          <Trophy className="h-8 w-8 text-yellow-500" />
          Leaderboard
        </h1>
        <p className="text-muted-foreground">
          Top players and their achievements
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="bg-card rounded-lg shadow-lg overflow-hidden"
      >
        <div className="grid grid-cols-5 gap-4 p-4 font-semibold border-b">
          <div>Rank</div>
          <div>Player</div>
          <div>Score</div>
          <div>Time</div>
          <div>Difficulty</div>
        </div>

        {leaderboardData.map((entry, index) => (
          <motion.div
            key={entry.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="grid grid-cols-5 gap-4 p-4 border-b hover:bg-accent/50 transition-colors"
          >
            <div className="flex items-center gap-2">
              {index === 0 && <Trophy className="h-5 w-5 text-yellow-500" />}
              {index === 1 && <Trophy className="h-5 w-5 text-gray-400" />}
              {index === 2 && <Trophy className="h-5 w-5 text-amber-700" />}
              {index > 2 && <span>{index + 1}</span>}
            </div>
            <div>{entry.name}</div>
            <div className="flex items-center gap-2">
              <Star className="h-4 w-4 text-yellow-500" />
              {entry.score}
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-blue-500" />
              {formatTime(entry.time)}
            </div>
            <div>
              <span className={`px-2 py-1 rounded-full text-sm ${
                entry.difficulty === 'Hard' ? 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-100' :
                entry.difficulty === 'Medium' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-100' :
                'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-100'
              }`}>
                {entry.difficulty}
              </span>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}