import { Book, Heart } from 'lucide-react'

export function Footer() {
  return (
    <footer className="bg-cream dark:bg-gray-900 py-8 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-center space-y-4">
          <div className="flex items-center space-x-2">
            <Book className="h-6 w-6 text-dusty-rose" />
            <span className="font-display text-xl">Classic Romance Book Club</span>
          </div>
          <p className="text-center text-gray-600 dark:text-gray-400">
            Join us in exploring timeless love stories that have captured hearts for generations.
          </p>
          <div className="flex items-center space-x-1 text-dusty-rose">
            <span>Made with</span>
            <Heart className="h-4 w-4" />
            <span>for book lovers</span>
          </div>
        </div>
      </div>
    </footer>
  )
}