import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        'soft-pink': 'var(--soft-pink)',
        'lavender': 'var(--lavender)',
        'mint-green': 'var(--mint-green)',
        'cream': 'var(--cream)',
        'dusty-rose': 'var(--dusty-rose)',
      },
      fontFamily: {
        serif: ['Source Serif Pro', 'serif'],
        display: ['Playfair Display', 'serif'],
      },
    },
  },
  plugins: [],
}

export default config