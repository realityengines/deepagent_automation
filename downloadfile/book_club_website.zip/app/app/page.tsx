"use client"

import { motion } from 'framer-motion'
import { Book, Heart, Users } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <Image
            src="https://i.pinimg.com/originals/34/3f/57/343f572c791e349a34fddeaebd9b8ac2.png"
            alt="Classic books background"
            fill
            className="object-cover opacity-30"
            priority
          />
        </div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative z-10 text-center px-4"
        >
          <h1 className="font-display text-5xl md:text-7xl mb-6">
            Classic Romance Book Club
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto">
            Join us in exploring timeless love stories that have captured hearts for generations
          </p>
          <Link
            href="/books"
            className="button-primary inline-flex items-center space-x-2"
          >
            <Book className="h-5 w-5" />
            <span>Explore Our Collection</span>
          </Link>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-cream dark:bg-gray-900">
        <div className="page-container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: Book,
                title: "Classic Novels",
                description: "Carefully curated collection of timeless romance classics"
              },
              {
                icon: Users,
                title: "Community",
                description: "Join fellow romance enthusiasts in meaningful discussions"
              },
              {
                icon: Heart,
                title: "Monthly Meetings",
                description: "Regular gatherings to discuss our featured book of the month"
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2 }}
                className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg"
              >
                <feature.icon className="h-8 w-8 text-dusty-rose mb-4" />
                <h3 className="font-display text-xl mb-2">{feature.title}</h3>
                <p className="text-gray-600 dark:text-gray-300">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Books Section */}
      <section className="py-16">
        <div className="page-container">
          <h2 className="section-header mb-12">Featured Books</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Pride and Prejudice",
                author: "Jane Austen",
                cover: "https://covers.openlibrary.org/b/id/14348537-L.jpg"
              },
              {
                title: "Jane Eyre",
                author: "Charlotte Brontë",
                cover: "https://covers.openlibrary.org/b/id/8235363-L.jpg"
              },
              {
                title: "Wuthering Heights",
                author: "Emily Brontë",
                cover: "https://covers.openlibrary.org/b/id/12818862-L.jpg"
              }
            ].map((book, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.2 }}
                className="book-card overflow-hidden"
              >
                <div className="relative aspect-[2/3]">
                  <Image
                    src={book.cover}
                    alt={book.title}
                    fill
                    className="object-cover rounded-t-lg"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-display text-xl mb-1">{book.title}</h3>
                  <p className="text-gray-600 dark:text-gray-300">{book.author}</p>
                </div>
              </motion.div>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link href="/books" className="button-secondary inline-flex items-center space-x-2">
              <Book className="h-5 w-5" />
              <span>View All Books</span>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}