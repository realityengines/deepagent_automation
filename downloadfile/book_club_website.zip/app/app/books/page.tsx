"use client"

import { motion } from 'framer-motion'
import { Book } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'

const books = [
  {
    id: "pride-and-prejudice",
    title: "Pride and Prejudice",
    author: "Jane Austen",
    cover: "https://covers.openlibrary.org/b/id/14348537-L.jpg",
    year: 1813
  },
  {
    id: "jane-eyre",
    title: "Jane Eyre",
    author: "Charlotte Brontë",
    cover: "https://covers.openlibrary.org/b/id/8235363-L.jpg",
    year: 1847
  },
  {
    id: "wuthering-heights",
    title: "Wuthering Heights",
    author: "Emily Brontë",
    cover: "https://covers.openlibrary.org/b/id/12818862-L.jpg",
    year: 1847
  },
  {
    id: "anna-karenina",
    title: "Anna Karenina",
    author: "Leo Tolstoy",
    cover: "https://covers.openlibrary.org/b/id/14890462-L.jpg",
    year: 1877
  },
  {
    id: "gone-with-the-wind",
    title: "Gone with the Wind",
    author: "Margaret Mitchell",
    cover: "https://covers.openlibrary.org/b/id/14817133-L.jpg",
    year: 1936
  },
  {
    id: "rebecca",
    title: "Rebecca",
    author: "Daphne du Maurier",
    cover: "https://covers.openlibrary.org/b/id/8238729-L.jpg",
    year: 1938
  },
  {
    id: "sense-and-sensibility",
    title: "Sense and Sensibility",
    author: "Jane Austen",
    cover: "https://covers.openlibrary.org/b/id/9278292-L.jpg",
    year: 1811
  },
  {
    id: "north-and-south",
    title: "North and South",
    author: "Elizabeth Gaskell",
    cover: "https://covers.openlibrary.org/b/id/8242253-L.jpg",
    year: 1855
  },
  {
    id: "age-of-innocence",
    title: "The Age of Innocence",
    author: "Edith Wharton",
    cover: "https://covers.openlibrary.org/b/id/11196262-L.jpg",
    year: 1920
  },
  {
    id: "persuasion",
    title: "Persuasion",
    author: "Jane Austen",
    cover: "https://covers.openlibrary.org/b/id/12824691-L.jpg",
    year: 1817
  },
  {
    id: "tenant-of-wildfell-hall",
    title: "The Tenant of Wildfell Hall",
    author: "Anne Brontë",
    cover: "https://covers.openlibrary.org/b/id/1023552-L.jpg",
    year: 1848
  },
  {
    id: "far-from-the-madding-crowd",
    title: "Far from the Madding Crowd",
    author: "Thomas Hardy",
    cover: "https://covers.openlibrary.org/b/id/902038-L.jpg",
    year: 1874
  }
]

export default function Books() {
  return (
    <div className="min-h-screen py-16">
      <div className="page-container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="section-header">Our Book Collection</h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Explore our carefully curated collection of classic romance novels
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {books.map((book, index) => (
            <motion.div
              key={book.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="book-card"
            >
              <div className="relative aspect-[2/3]">
                <Image
                  src={book.cover}
                  alt={book.title}
                  fill
                  className="object-cover rounded-t-lg"
                />
              </div>
              <div className="p-6">
                <h2 className="font-display text-2xl mb-2">{book.title}</h2>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  {book.author} • {book.year}
                </p>
                <Link
                  href={`/books/${book.id}`}
                  className="button-primary inline-flex items-center space-x-2"
                >
                  <Book className="h-5 w-5" />
                  <span>Read More</span>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}