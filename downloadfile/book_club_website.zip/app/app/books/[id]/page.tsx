"use client"

import { motion } from 'framer-motion'
import { Book, Calendar, User } from 'lucide-react'
import Image from 'next/image'
import { useParams } from 'next/navigation'

const booksData = {
  "pride-and-prejudice": {
    title: "Pride and Prejudice",
    author: "Jane Austen",
    year: 1813,
    cover: "https://covers.openlibrary.org/b/id/14348537-L.jpg",
    summary: "Set in rural England in the early 19th century, \"Pride and Prejudice\" follows the Bennet family, particularly the second eldest daughter Elizabeth. When wealthy bachelor Mr. Bingley arrives in the neighborhood along with his friend, the even wealthier and more reserved Mr. Darcy, Mrs. Bennet sees an opportunity for her daughters.",
    themes: [
      "Pride, prejudice, and first impressions",
      "Social class and economic realities of women in Regency England",
      "Marriage as economic security versus marriage for love",
      "Personal growth and self-awareness",
      "The constraints of societal expectations"
    ],
    discussionPoints: [
      "How do Elizabeth and Darcy each overcome their flaws (her prejudice, his pride) throughout the novel?",
      "Discuss the various marriages presented in the novel. What does Austen seem to be saying about marriage as an institution?",
      "How does the novel explore the limited options available to women in early 19th century England?",
      "What role does the concept of \"reputation\" play throughout the story?",
      "How relevant are the themes of pride and prejudice in modern relationships?"
    ]
  },
  "jane-eyre": {
    title: "Jane Eyre",
    author: "Charlotte Brontë",
    year: 1847,
    cover: "https://covers.openlibrary.org/b/id/8235363-L.jpg",
    summary: "\"Jane Eyre\" follows the life of its eponymous heroine from her troubled childhood as an orphan to her adult life and romance with the brooding Mr. Rochester. After enduring a harsh upbringing at Lowood School, Jane becomes a governess at Thornfield Hall, where she falls in love with her enigmatic employer, Edward Rochester.",
    themes: [
      "Female independence and autonomy",
      "Social class and gender inequality",
      "Gothic elements and supernatural occurrences",
      "Morality versus passion",
      "Religion and spirituality",
      "Fire and ice as symbolic elements"
    ],
    discussionPoints: [
      "How does Jane maintain her independence and sense of self throughout the novel despite societal constraints?",
      "Discuss the Gothic elements in the novel and how they contribute to the atmosphere and plot.",
      "What is the significance of the \"madwoman in the attic\" and what might Bertha symbolize?",
      "How does the novel balance Christian morality with romantic passion?",
      "In what ways is Jane Eyre considered a proto-feminist novel?"
    ]
  },
  "wuthering-heights": {
    title: "Wuthering Heights",
    author: "Emily Brontë",
    year: 1847,
    cover: "https://covers.openlibrary.org/b/id/12818862-L.jpg",
    summary: "\"Wuthering Heights\" tells the turbulent story of Catherine Earnshaw and Heathcliff, set on the Yorkshire moors. When Mr. Earnshaw brings home an orphaned Heathcliff, his daughter Catherine forms an intense bond with him, while his son Hindley grows jealous.",
    themes: [
      "Destructive, all-consuming love",
      "Revenge and generational trauma",
      "Social class and outsider status",
      "Nature as reflection of human emotion",
      "The supernatural and Gothic elements",
      "Cycles of abuse and redemption"
    ],
    discussionPoints: [
      "Is the relationship between Catherine and Heathcliff true love or a destructive obsession?",
      "How does the novel use the Yorkshire moors as both setting and metaphor?",
      "Discuss how the structure of the novel affects your understanding of the story.",
      "How does the second generation mirror or break free from the patterns of the first?",
      "What makes this novel endure as a romance despite its dark themes?"
    ]
  },
  "anna-karenina": {
    title: "Anna Karenina",
    author: "Leo Tolstoy",
    year: 1877,
    cover: "https://covers.openlibrary.org/b/id/14890462-L.jpg",
    summary: "\"Anna Karenina\" follows two main storylines: the tragic affair of Anna Karenina and Count Vronsky, and the contrasting relationship between Konstantin Levin and Kitty Shcherbatsky.",
    themes: [
      "Societal hypocrisy and moral judgment",
      "Marriage versus passion",
      "Rural versus urban life",
      "Faith and spirituality",
      "Family dynamics",
      "The role of women in 19th century Russian society",
      "Trains as symbols of modernization and destruction"
    ],
    discussionPoints: [
      "Compare and contrast the two main relationships in the novel: Anna/Vronsky and Levin/Kitty.",
      "How does Tolstoy use Anna's story to critique social norms and hypocrisies of Russian aristocratic society?",
      "Discuss the novel's famous opening line about happy and unhappy families.",
      "What role does forgiveness play throughout the novel?",
      "How does Tolstoy use the character of Levin to explore his own philosophical questions?"
    ]
  },
  "gone-with-the-wind": {
    title: "Gone with the Wind",
    author: "Margaret Mitchell",
    year: 1936,
    cover: "https://covers.openlibrary.org/b/id/14817133-L.jpg",
    summary: "\"Gone with the Wind\" chronicles the life of the headstrong Scarlett O'Hara against the backdrop of the American Civil War and Reconstruction era in Georgia.",
    themes: [
      "Survival and resilience",
      "The fall of the Old South and its aristocratic values",
      "Unrequited love and romantic delusion",
      "The contrast between pragmatism and idealism",
      "Gender roles and expectations",
      "Land as a source of identity and strength",
      "War and its societal impact"
    ],
    discussionPoints: [
      "How does Scarlett's character evolve throughout the novel? Is she ultimately a heroine or an anti-heroine?",
      "Discuss the novel's portrayal of the antebellum South and its problematic romanticization.",
      "Analyze the complex relationship between Scarlett and Rhett.",
      "How does the novel contrast Scarlett with Melanie?",
      "What is the significance of land, particularly Tara, throughout the story?"
    ]
  },
  "rebecca": {
    title: "Rebecca",
    author: "Daphne du Maurier",
    year: 1938,
    cover: "https://covers.openlibrary.org/b/id/8238729-L.jpg",
    summary: "\"Rebecca\" begins with the famous line, \"Last night I dreamt I went to Manderley again,\" spoken by the unnamed narrator, a young woman who serves as companion to an American socialite.",
    themes: [
      "Identity and self-doubt",
      "The haunting presence of the past",
      "Marriage and power dynamics",
      "Jealousy and obsession",
      "Appearances versus reality",
      "Gothic elements and psychological suspense",
      "The house as a character"
    ],
    discussionPoints: [
      "Why do you think the narrator remains unnamed throughout the novel?",
      "Discuss the role of Mrs. Danvers in the novel.",
      "How does the novel explore the theme of identity?",
      "What makes \"Rebecca\" a romance novel despite its elements of mystery?",
      "How does the setting of Manderley contribute to the atmosphere?"
    ]
  },
  "sense-and-sensibility": {
    title: "Sense and Sensibility",
    author: "Jane Austen",
    year: 1811,
    cover: "https://covers.openlibrary.org/b/id/9278292-L.jpg",
    summary: "\"Sense and Sensibility\" follows the Dashwood sisters—practical, reserved Elinor and emotional, expressive Marianne—after their father's death leaves them in reduced circumstances.",
    themes: [
      "The balance between reason and emotion",
      "Economic vulnerability of women",
      "Social expectations and constraints",
      "Loyalty and betrayal",
      "Appearance versus reality",
      "The nature of true love versus infatuation",
      "Sisterhood and family bonds"
    ],
    discussionPoints: [
      "Compare and contrast Elinor and Marianne's approaches to love and life.",
      "Discuss how financial considerations affect the marriage prospects.",
      "How does Austen use secondary characters to comment on society?",
      "What is Austen suggesting about the ideal balance between \"sense\" and \"sensibility\"?",
      "How does this novel compare to Austen's other works?"
    ]
  },
  "north-and-south": {
    title: "North and South",
    author: "Elizabeth Gaskell",
    year: 1855,
    cover: "https://covers.openlibrary.org/b/id/8242253-L.jpg",
    summary: "\"North and South\" centers on Margaret Hale, a young woman from southern England whose family relocates to the industrial northern town of Milton.",
    themes: [
      "Class conflict and social change",
      "Industrial revolution and its human cost",
      "North versus South cultural divisions",
      "Pride and prejudice",
      "Faith and doubt",
      "The role of women in Victorian society",
      "Labor relations and early capitalism"
    ],
    discussionPoints: [
      "How does the novel use geographical contrast to explore deeper divisions?",
      "Compare the character development of Margaret and Thornton.",
      "Discuss how Gaskell portrays industrial working conditions.",
      "How does the novel address Victorian gender roles?",
      "In what ways does it challenge Victorian romance conventions?"
    ]
  },
  "age-of-innocence": {
    title: "The Age of Innocence",
    author: "Edith Wharton",
    year: 1920,
    cover: "https://covers.openlibrary.org/b/id/11196262-L.jpg",
    summary: "Set in 1870s New York high society, \"The Age of Innocence\" follows Newland Archer, a young lawyer engaged to the beautiful but conventional May Welland.",
    themes: [
      "Social conformity versus individual desire",
      "The price of convention and respectability",
      "The gilded cage of upper-class society",
      "Unfulfilled love and sacrifice",
      "Appearance versus reality",
      "The changing role of women",
      "Old New York versus European influences"
    ],
    discussionPoints: [
      "How does Wharton use Ellen Olenska to challenge social norms?",
      "Discuss the significance of Newland's final decision.",
      "How does May Welland evolve as a character?",
      "What commentary does Wharton make about marriage?",
      "How does the novel's title work on multiple levels?"
    ]
  },
  "persuasion": {
    title: "Persuasion",
    author: "Jane Austen",
    year: 1817,
    cover: "https://covers.openlibrary.org/b/id/12824691-L.jpg",
    summary: "\"Persuasion,\" Jane Austen's final completed novel, centers on Anne Elliot, a 27-year-old woman who, eight years earlier, was persuaded to break off her engagement to Frederick Wentworth.",
    themes: [
      "Second chances and renewed love",
      "The consequences of persuasion and influence",
      "Constancy in love",
      "Social class and its limitations",
      "The changing social order",
      "Maturity and personal growth",
      "Regret and resilience"
    ],
    discussionPoints: [
      "How does Anne Elliot differ from Austen's other heroines?",
      "Discuss the novel's exploration of persuasion.",
      "How does the novel portray changing social hierarchy?",
      "What role does letter writing play in the novel?",
      "How does the theme of autumn reflect second chances?"
    ]
  },
  "tenant-of-wildfell-hall": {
    title: "The Tenant of Wildfell Hall",
    author: "Anne Brontë",
    year: 1848,
    cover: "https://covers.openlibrary.org/b/id/1023552-L.jpg",
    summary: "\"The Tenant of Wildfell Hall\" begins when a mysterious widow, Helen Graham, and her young son take up residence at the dilapidated Wildfell Hall.",
    themes: [
      "Marriage, divorce, and women's legal rights",
      "Alcoholism and moral degradation",
      "The double standard between men and women",
      "Art as female independence",
      "Motherhood and child-rearing",
      "Religious faith and moral strength",
      "The tension between truth and reputation"
    ],
    discussionPoints: [
      "How does Anne Brontë's portrayal of marriage differ from her sisters'?",
      "Discuss the novel's radical stance on women's rights.",
      "How does the narrative structure affect your understanding?",
      "What commentary does the novel make about alcoholism?",
      "How does Helen's art function throughout the novel?"
    ]
  },
  "far-from-the-madding-crowd": {
    title: "Far from the Madding Crowd",
    author: "Thomas Hardy",
    year: 1874,
    cover: "https://covers.openlibrary.org/b/id/902038-L.jpg",
    summary: "\"Far from the Madding Crowd\" follows the independent and spirited Bathsheba Everdene, who inherits her uncle's farm and decides to run it herself.",
    themes: [
      "Female independence and its challenges",
      "The consequences of impulsive decisions",
      "Nature as both setting and metaphor",
      "Different models of masculinity",
      "Rural life and agricultural traditions",
      "Fate, chance, and human choice",
      "Class differences and social expectations"
    ],
    discussionPoints: [
      "How does Hardy use the rural setting to reflect emotional lives?",
      "Compare and contrast the three suitors in Bathsheba's life.",
      "Discuss Bathsheba's character development.",
      "How does the novel challenge Victorian gender roles?",
      "What is the significance of the novel's title?"
    ]
  }
} as const

export default function BookDetail() {
  const { id } = useParams()
  const book = booksData[id as keyof typeof booksData]

  if (!book) {
    return <div>Book not found</div>
  }

  return (
    <div className="min-h-screen py-16">
      <div className="page-container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-1 md:grid-cols-2 gap-12"
        >
          <div className="relative aspect-[2/3] md:sticky md:top-24">
            <Image
              src={book.cover}
              alt={book.title}
              fill
              className="object-cover rounded-lg shadow-xl"
            />
          </div>

          <div className="space-y-8">
            <div>
              <h1 className="font-display text-4xl md:text-5xl mb-4">{book.title}</h1>
              <div className="flex flex-wrap gap-4 text-gray-600 dark:text-gray-300">
                <div className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  <span>{book.author}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  <span>{book.year}</span>
                </div>
              </div>
            </div>

            <div>
              <h2 className="font-display text-2xl mb-4">Summary</h2>
              <p className="text-gray-600 dark:text-gray-300">{book.summary}</p>
            </div>

            <div>
              <h2 className="font-display text-2xl mb-4">Key Themes</h2>
              <ul className="space-y-2">
                {book.themes.map((theme, index) => (
                  <motion.li
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center gap-2 text-gray-600 dark:text-gray-300"
                  >
                    <Book className="h-4 w-4 text-dusty-rose" />
                    <span>{theme}</span>
                  </motion.li>
                ))}
              </ul>
            </div>

            <div>
              <h2 className="font-display text-2xl mb-4">Discussion Points</h2>
              <ul className="space-y-4">
                {book.discussionPoints.map((point, index) => (
                  <motion.li
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-cream dark:bg-gray-800 p-4 rounded-lg"
                  >
                    {point}
                  </motion.li>
                ))}
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}