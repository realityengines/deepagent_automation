"use client"

import { motion } from 'framer-motion'
import { Book, Heart, Users, Calendar } from 'lucide-react'

export default function About() {
  return (
    <div className="min-h-screen py-16">
      <div className="page-container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="section-header">About Our Book Club</h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Welcome to the Classic Romance Book Club, where timeless love stories come to life
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            className="bg-cream dark:bg-gray-800 p-8 rounded-lg"
          >
            <h2 className="font-display text-3xl mb-4">Our Mission</h2>
            <p className="text-gray-600 dark:text-gray-300">
              We are dedicated to celebrating and exploring the rich tradition of classic romance literature.
              Through our monthly meetings and discussions, we aim to keep these timeless stories alive
              and relevant for contemporary readers.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            className="bg-soft-pink dark:bg-gray-800 p-8 rounded-lg"
          >
            <h2 className="font-display text-3xl mb-4">What We Do</h2>
            <ul className="space-y-4">
              {[
                {
                  icon: Book,
                  text: "Read and discuss classic romance novels"
                },
                {
                  icon: Users,
                  text: "Foster a community of passionate readers"
                },
                {
                  icon: Calendar,
                  text: "Host monthly book club meetings"
                },
                {
                  icon: Heart,
                  text: "Share our love for timeless literature"
                }
              ].map((item, index) => (
                <li key={index} className="flex items-center space-x-3">
                  <item.icon className="h-6 w-6 text-dusty-rose" />
                  <span>{item.text}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </div>
  )
}