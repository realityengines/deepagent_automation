'use client';

import { Clock, Star } from 'lucide-react';

interface GameStatsProps {
  score: number;
  time: number;
}

export function GameStats({ score, time }: GameStatsProps) {
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-card p-4 rounded-lg shadow-lg space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <Star className="h-5 w-5 mr-2 text-yellow-500" />
          <span className="text-sm font-medium">Score</span>
        </div>
        <span className="text-lg font-bold">{score}</span>
      </div>
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <Clock className="h-5 w-5 mr-2 text-blue-500" />
          <span className="text-sm font-medium">Time</span>
        </div>
        <span className="text-lg font-bold">{formatTime(time)}</span>
      </div>
    </div>
  );
}