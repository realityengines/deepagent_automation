'use client';

import { motion } from 'framer-motion';
import { useState } from 'react';
import SudokuBoard from '@/components/sudoku-board';
import GameControls from '@/components/game-controls';
import { GameStats } from '@/components/game-stats';
import { Button } from '@/components/ui/button';
import { Gamepad2, HelpCircle } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

export default function Home() {
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('easy');
  const [gameStarted, setGameStarted] = useState(false);
  const [score, setScore] = useState(0);
  const [time, setTime] = useState(0);

  const startNewGame = () => {
    setGameStarted(true);
    setScore(0);
    setTime(0);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-8"
      >
        <h1 className="text-4xl font-bold mb-4">Sudoku Challenge</h1>
        <p className="text-muted-foreground mb-6">
          Challenge yourself with our interactive Sudoku puzzle!
        </p>
      </motion.div>

      <div className="flex flex-col lg:flex-row gap-8 items-start justify-center">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="w-full lg:w-auto"
        >
          {!gameStarted ? (
            <div className="bg-card p-6 rounded-lg shadow-lg">
              <h2 className="text-2xl font-semibold mb-4">Start New Game</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Select Difficulty:</label>
                  <div className="flex gap-2">
                    {['easy', 'medium', 'hard'].map((level) => (
                      <Button
                        key={level}
                        variant={difficulty === level ? "default" : "outline"}
                        onClick={() => setDifficulty(level as 'easy' | 'medium' | 'hard')}
                      >
                        {level.charAt(0).toUpperCase() + level.slice(1)}
                      </Button>
                    ))}
                  </div>
                </div>
                <Button onClick={startNewGame} className="w-full">
                  <Gamepad2 className="mr-2 h-4 w-4" />
                  Start Game
                </Button>
              </div>
            </div>
          ) : (
            <SudokuBoard difficulty={difficulty} />
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="w-full lg:w-64 space-y-6"
        >
          <GameStats score={score} time={time} />
          <GameControls />
          
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full">
                <HelpCircle className="mr-2 h-4 w-4" />
                How to Play
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>How to Play Sudoku</DialogTitle>
                <DialogDescription>
                  <ul className="list-disc list-inside space-y-2 mt-4">
                    <li>Fill in the empty cells with numbers from 1 to 9</li>
                    <li>Each row must contain all numbers from 1-9 without repetition</li>
                    <li>Each column must contain all numbers from 1-9 without repetition</li>
                    <li>Each 3x3 box must contain all numbers from 1-9 without repetition</li>
                    <li>Use hints if you get stuck</li>
                    <li>Try to complete the puzzle in the shortest time possible</li>
                  </ul>
                </DialogDescription>
              </DialogHeader>
            </DialogContent>
          </Dialog>
        </motion.div>
      </div>
    </div>
  );
}