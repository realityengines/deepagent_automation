'use client';

import { motion } from 'framer-motion';
import { Settings, Volume2, Sun, Moon, Timer, Gamepad } from 'lucide-react';
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { useTheme } from 'next-themes';
import { useState } from 'react';

export default function SettingsPage() {
  const { theme, setTheme } = useTheme();
  const [volume, setVolume] = useState([50]);
  
  return (
    <div className="container max-w-2xl mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-8"
      >
        <h1 className="text-4xl font-bold mb-4 flex items-center justify-center gap-2">
          <Settings className="h-8 w-8" />
          Settings
        </h1>
        <p className="text-muted-foreground">
          Customize your game experience
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="space-y-6"
      >
        <div className="bg-card rounded-lg p-6 shadow-lg space-y-6">
          <h2 className="text-xl font-semibold mb-4">Game Settings</h2>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Timer className="h-5 w-5" />
              <Label htmlFor="show-timer">Show Timer</Label>
            </div>
            <Switch id="show-timer" />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gamepad className="h-5 w-5" />
              <Label htmlFor="auto-check">Auto-check Moves</Label>
            </div>
            <Switch id="auto-check" />
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Volume2 className="h-5 w-5" />
              <Label>Sound Volume</Label>
            </div>
            <Slider
              value={volume}
              onValueChange={setVolume}
              max={100}
              step={1}
            />
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card rounded-lg p-6 shadow-lg"
        >
          <h2 className="text-xl font-semibold mb-4">Theme Settings</h2>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {theme === 'dark' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
              <Label>Dark Mode</Label>
            </div>
            <Switch
              checked={theme === 'dark'}
              onCheckedChange={(checked) => setTheme(checked ? 'dark' : 'light')}
            />
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}